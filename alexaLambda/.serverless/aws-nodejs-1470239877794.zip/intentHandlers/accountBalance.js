'use strict';

function accountBalance() {}

accountBalance.prototype.intentHandlers = {

};

module.exports = new accountBalance();