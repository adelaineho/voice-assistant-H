'use strict';

function jobComplete() {}

jobComplete.prototype.intentHandlers = {

};

module.exports = new jobComplete();