'use strict';

function howToBeAwesome() {}

howToBeAwesome.prototype.intentHandlers = {

};

module.exports = new howToBeAwesome();